using Dapr;
using Dapr.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

namespace OrderServiceApp
{
    // Minimal Product class
    public class Product
    {
        public string Id { get; set; } = "";
        public string Name { get; set; } = "";
        public decimal Price { get; set; }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var app = builder.Build();

            // Dapr subscription endpoint
            app.MapPost("/orders", async (HttpContext context) =>
            {
                try
                {
                    var product = await JsonSerializer.DeserializeAsync<Product>(context.Request.Body);
                    if (product != null)
                    {
                        Console.WriteLine($"Received Product event: Id={product.Id}, Name={product.Name}, Price={product.Price}");
                        // Implement order creation logic here
                    }
                    context.Response.StatusCode = 200;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error processing product event: {ex.Message}");
                    context.Response.StatusCode = 500;
                }
            });

            // Health check endpoint
            app.MapGet("/health", () => Results.Ok("OrderService is running"));

            app.Run();
        }
    }
}
