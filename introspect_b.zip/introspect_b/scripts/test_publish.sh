#!/usr/bin/env bash
set -euo pipefail

RESOURCE_GROUP="${RESOURCE_GROUP:-introspect_b_grp}"
PRODUCT_APP="${PRODUCT_APP:-productservice}"

PRODUCT_URL=$(az containerapp show --name "$PRODUCT_APP" --resource-group "$RESOURCE_GROUP" --query "properties.configuration.ingress.fqdn" -o tsv)
echo "ProductService URL: https://${PRODUCT_URL}/products"

curl -s -X POST "https://${PRODUCT_URL}/products"   -H "Content-Type: application/json"   -d '{"id":"1","name":"Widget","price":9.99}' | jq .