#!/usr/bin/env bash
set -euo pipefail

RESOURCE_GROUP="${RESOURCE_GROUP:-introspect_b_grp}"
PRODUCT_APP="${PRODUCT_APP:-productservice}"
ORDER_APP="${ORDER_APP:-orderservice}"

echo "Deleting container apps (idempotent)..."
az containerapp delete --name "$PRODUCT_APP" --resource-group "$RESOURCE_GROUP" --yes || true
az containerapp delete --name "$ORDER_APP" --resource-group "$RESOURCE_GROUP" --yes || true
echo "Done."