# Azure OpenAI – Guidance Prompts

Use these prompts to have Azure OpenAI review your setup and suggest improvements.

## Prompt: Telemetry & Retries
> You're an SRE reviewing two ACA microservices (ProductService publishes to topic `products`, OrderService subscribes). Dapr is enabled. Suggest:
> 1) Missing telemetry points (structured logs, tracing spans, correlation IDs).
> 2) Retry/backoff strategies for publish and handler, with idempotency hints.
> 3) Minimal App Insights queries to verify end-to-end success/latency/error rates.

## Prompt: Dockerfile & Dapr Components
> Review the following Dockerfile(s) and Dapr component YAML. Point out inefficiencies, security issues, or missing health probes. Suggest production-ready alternatives and multi-arch build tips.
> ---
> {{dockerfiles_and_yaml_here}}

## Prompt: Scaling Pub/Sub
> We use ACA with Dapr pub/sub (in-memory for test; Service Bus in prod). Explain scaling strategies for sudden spikes:
> - Horizontal scaling rules in ACA (HTTP RPS, CPU, KEDA-based queue length for Service Bus).
> - Dapr consumer concurrency, maxInflight, and bulk subscribe.
> - Backpressure, DLQs, and poison-message handling.