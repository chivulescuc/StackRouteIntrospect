#!/usr/bin/env bash
set -euo pipefail

# Change these if needed
RESOURCE_GROUP="${RESOURCE_GROUP:-introspect_b_grp}"
LOCATION="${LOCATION:-eastus2}"
ENV_NAME="${ENV_NAME:-introspect-env}"
ACR_NAME="${ACR_NAME:-introspectacr}"

PRODUCT_APP="${PRODUCT_APP:-productservice}"
ORDER_APP="${ORDER_APP:-orderservice}"

# Enable ACR admin and fetch creds (bypasses RBAC role assignment requirement)
echo "Enabling ACR admin on $ACR_NAME (if not already enabled)..."
az acr update -n "$ACR_NAME" --admin-enabled true >/dev/null

REGISTRY_USERNAME=$(az acr credential show --name "$ACR_NAME" --query "username" -o tsv)
REGISTRY_PASSWORD=$(az acr credential show --name "$ACR_NAME" --query "passwords[0].value" -o tsv)
REGISTRY_SERVER="${ACR_NAME}.azurecr.io"

echo "Creating resource group $RESOURCE_GROUP (idempotent)..."
az group create --name "$RESOURCE_GROUP" --location "$LOCATION" >/dev/null

echo "Creating Container Apps environment $ENV_NAME (idempotent)..."
az containerapp env create   --name "$ENV_NAME"   --resource-group "$RESOURCE_GROUP"   --location "$LOCATION" >/dev/null

# Create or update ProductService
echo "Deploying $PRODUCT_APP ..."
if az containerapp show --name "$PRODUCT_APP" --resource-group "$RESOURCE_GROUP" >/dev/null 2>&1; then
  az containerapp update     --name "$PRODUCT_APP"     --resource-group "$RESOURCE_GROUP"     --image "${REGISTRY_SERVER}/${PRODUCT_APP}:latest"     --cpu 0.5 --memory 1Gi     --enable-dapr     --dapr-app-id "$PRODUCT_APP"     --dapr-app-port 80     --registry-server "$REGISTRY_SERVER"     --registry-username "$REGISTRY_USERNAME"     --registry-password "$REGISTRY_PASSWORD" >/dev/null
else
  az containerapp create     --name "$PRODUCT_APP"     --resource-group "$RESOURCE_GROUP"     --environment "$ENV_NAME"     --image "${REGISTRY_SERVER}/${PRODUCT_APP}:latest"     --target-port 80     --ingress external     --cpu 0.5 --memory 1Gi     --enable-dapr     --dapr-app-id "$PRODUCT_APP"     --dapr-app-port 80     --registry-server "$REGISTRY_SERVER"     --registry-username "$REGISTRY_USERNAME"     --registry-password "$REGISTRY_PASSWORD" >/dev/null
fi

# Create or update OrderService
echo "Deploying $ORDER_APP ..."
if az containerapp show --name "$ORDER_APP" --resource-group "$RESOURCE_GROUP" >/dev/null 2>&1; then
  az containerapp update     --name "$ORDER_APP"     --resource-group "$RESOURCE_GROUP"     --image "${REGISTRY_SERVER}/${ORDER_APP}:latest"     --cpu 0.5 --memory 1Gi     --enable-dapr     --dapr-app-id "$ORDER_APP"     --dapr-app-port 80     --registry-server "$REGISTRY_SERVER"     --registry-username "$REGISTRY_USERNAME"     --registry-password "$REGISTRY_PASSWORD" >/dev/null
else
  az containerapp create     --name "$ORDER_APP"     --resource-group "$RESOURCE_GROUP"     --environment "$ENV_NAME"     --image "${REGISTRY_SERVER}/${ORDER_APP}:latest"     --target-port 80     --ingress external     --cpu 0.5 --memory 1Gi     --enable-dapr     --dapr-app-id "$ORDER_APP"     --dapr-app-port 80     --registry-server "$REGISTRY_SERVER"     --registry-username "$REGISTRY_USERNAME"     --registry-password "$REGISTRY_PASSWORD" >/dev/null
fi

echo "Done."