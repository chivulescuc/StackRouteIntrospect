using Dapr;
using Dapr.Client;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Hosting;
using System.Text.Json;

namespace ProductServiceApp
{
    // Product class defined locally
    public class Product
    {
        public string Id { get; set; } = "";
        public string Name { get; set; } = "";
        public decimal Price { get; set; }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            var app = builder.Build();

            // Endpoint to publish Product events via Dapr pub/sub
            app.MapPost("/products", async (HttpContext context) =>
            {
                try
                {
                    var product = await JsonSerializer.DeserializeAsync<Product>(context.Request.Body);
                    if (product != null)
                    {
                        Console.WriteLine($"Publishing Product event: Id={product.Id}, Name={product.Name}, Price={product.Price}");

                        var daprClient = new DaprClientBuilder().Build();
                        await daprClient.PublishEventAsync("pubsub", "products", product);
                    }
                    context.Response.StatusCode = 200;
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error publishing product event: {ex.Message}");
                    context.Response.StatusCode = 500;
                }
            });

            // Health check
            app.MapGet("/health", () => Results.Ok("ProductService is running"));

            app.Run();
        }
    }
}
